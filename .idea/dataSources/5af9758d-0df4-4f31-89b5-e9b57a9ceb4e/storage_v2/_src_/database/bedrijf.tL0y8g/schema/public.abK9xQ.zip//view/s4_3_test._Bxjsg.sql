create view s4_3_test(cursus, begindatum, aantal_inschrijvingen) as
SELECT answer.cursus,
       answer.begindatum,
       answer.aantal_inschrijvingen
FROM (VALUES ('JAV'::character varying(4), '2019-12-13'::date, 5::bigint),
             ('OAG'::character varying, '2019-08-10'::date, 3),
             ('S02'::character varying, '2019-04-12'::date, 4),
             ('S02'::character varying, '2019-10-04'::date, 3)) answer(cursus, begindatum, aantal_inschrijvingen);

alter table s4_3_test
    owner to postgres;

