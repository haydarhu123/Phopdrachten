create view s5_5(cursus, begindatum) as
SELECT u.cursus,
       u.begindatum
FROM uitvoeringen u
WHERE (u.cursus::text IN (SELECT c.code
                          FROM cursussen c
                          WHERE c.code::text = u.cursus::text
                            AND c.type = 'BLD'::bpchar
                            AND u.begindatum >= '2020-01-01'::date
                            AND u.begindatum <= '2021-01-01'::date));

alter table s5_5
    owner to postgres;

