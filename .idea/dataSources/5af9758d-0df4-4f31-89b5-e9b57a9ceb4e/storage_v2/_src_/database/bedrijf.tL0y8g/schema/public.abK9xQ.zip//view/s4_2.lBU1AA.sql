create view s4_2(naam) as
SELECT medewerkers.naam
FROM medewerkers
WHERE medewerkers.naam::text ~~ '% %'::text;

alter table s4_2
    owner to postgres;

