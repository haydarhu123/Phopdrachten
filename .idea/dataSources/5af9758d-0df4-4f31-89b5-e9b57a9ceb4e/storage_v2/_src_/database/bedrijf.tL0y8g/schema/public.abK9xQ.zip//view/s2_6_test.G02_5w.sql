create view s2_6_test(naam) as
SELECT medewerkers.naam
FROM medewerkers
WHERE medewerkers.mnr >= 8000::numeric
  AND medewerkers.functie::text = 'STAGIAIR'::text;

alter table s2_6_test
    owner to postgres;

