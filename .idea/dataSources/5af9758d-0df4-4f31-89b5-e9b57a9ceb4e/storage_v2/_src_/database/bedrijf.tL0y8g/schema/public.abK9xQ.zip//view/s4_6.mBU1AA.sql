create view s4_6(verschil, gemiddeld) as
SELECT max(medewerkers.gbdatum) - min(medewerkers.gbdatum)     AS verschil,
       avg(age(medewerkers.gbdatum::timestamp with time zone)) AS gemiddeld
FROM medewerkers
GROUP BY medewerkers.gbdatum;

alter table s4_6
    owner to postgres;

