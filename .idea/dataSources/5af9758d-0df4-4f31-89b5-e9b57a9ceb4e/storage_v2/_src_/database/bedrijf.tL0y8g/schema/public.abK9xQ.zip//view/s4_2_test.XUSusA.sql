create view s4_2_test(naam) as
SELECT answer.naam
FROM (VALUES ('DE WAARD'::character varying(12)),
             ('DE KONING'::character varying),
             ('DEN DRAAIER'::character varying)) answer(naam);

alter table s4_2_test
    owner to postgres;

