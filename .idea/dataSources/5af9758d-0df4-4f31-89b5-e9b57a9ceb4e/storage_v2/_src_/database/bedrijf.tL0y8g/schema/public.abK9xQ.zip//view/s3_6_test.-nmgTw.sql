create view s3_6_test(naam, toelage) as
SELECT answer.naam,
       answer.toelage
FROM (VALUES ('ALDERS'::character varying(12), 100.00::numeric(6, 2)),
             ('DE WAARD'::character varying, 50.00),
             ('JANSEN'::character varying, 200.00),
             ('MARTENS'::character varying, 50.00),
             ('BLAAK'::character varying, 200.00),
             ('CLERCKX'::character varying, 200.00),
             ('SCHOTTEN'::character varying, 200.00),
             ('DE KONING'::character varying, 500.00),
             ('DEN DRAAIER'::character varying, 100.00),
             ('ADAMS'::character varying, 0.00),
             ('SPIJKER'::character varying, 200.00),
             ('MOLENAAR'::character varying, 50.00),
             ('SMIT'::character varying, 0.00),
             ('JANSEN'::character varying, 0.00)) answer(naam, toelage);

alter table s3_6_test
    owner to postgres;

