create view s5_8_test(naam) as
SELECT answer.naam
FROM (VALUES ('DE KONING'::character varying(12)),
             ('MOLENAAR'::character varying),
             ('MARTENS'::character varying),
             ('DE WAARD'::character varying),
             ('BLAAK'::character varying),
             ('JANSEN'::character varying),
             ('ALDERS'::character varying),
             ('CLERCKX'::character varying),
             ('DEN DRAAIER'::character varying)) answer(naam);

alter table s5_8_test
    owner to postgres;

