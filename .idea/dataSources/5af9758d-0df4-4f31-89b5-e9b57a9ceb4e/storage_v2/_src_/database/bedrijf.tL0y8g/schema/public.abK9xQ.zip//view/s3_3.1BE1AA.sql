create view s3_3(afdeling, hoofd) as
SELECT a.naam AS afdeling,
       m.naam AS hoofd
FROM medewerkers m
         JOIN afdelingen a ON a.hoofd = m.mnr;

alter table s3_3
    owner to postgres;

