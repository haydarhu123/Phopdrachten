create view s4_4_test(cursist, cursus) as
SELECT answer.cursist,
       answer.cursus
FROM (VALUES (7788::numeric(4, 0), 'JAV'::character varying(4)),
             (7902, 'S02'::character varying),
             (7698, 'S02'::character varying)) answer(cursist, cursus);

alter table s4_4_test
    owner to postgres;

