create view s1_5_test(naam) as
SELECT medewerkers.naam
FROM medewerkers
WHERE medewerkers.mnr < 9000::numeric;

alter table s1_5_test
    owner to postgres;

