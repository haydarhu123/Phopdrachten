create view deelnemers(cursist, cursus, begindatum, docent, locatie) as
SELECT inschrijvingen.cursist,
       inschrijvingen.cursus,
       inschrijvingen.begindatum,
       uitvoeringen.docent,
       uitvoeringen.locatie
FROM inschrijvingen,
     uitvoeringen;

alter table deelnemers
    owner to postgres;

