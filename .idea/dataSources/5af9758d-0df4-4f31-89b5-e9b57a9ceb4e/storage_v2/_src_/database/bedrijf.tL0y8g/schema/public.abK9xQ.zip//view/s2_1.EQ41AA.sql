create view s2_1(code, omschrijving) as
SELECT cursussen.code,
       cursussen.omschrijving
FROM cursussen
WHERE cursussen.lengte = 4::numeric;

alter table s2_1
    owner to postgres;

