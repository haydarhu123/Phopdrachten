create view s2_1_test(code, omschrijving) as
SELECT cursussen.code,
       cursussen.omschrijving
FROM cursussen
WHERE cursussen.code::text = ANY
      (ARRAY ['S02'::character varying, 'JAV'::character varying, 'GEN'::character varying]::text[]);

alter table s2_1_test
    owner to postgres;

