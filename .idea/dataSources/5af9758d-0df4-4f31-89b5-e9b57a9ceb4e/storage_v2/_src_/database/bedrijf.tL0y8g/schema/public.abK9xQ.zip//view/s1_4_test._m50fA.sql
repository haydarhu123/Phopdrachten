create view s1_4_test(column_name) as
SELECT columns.column_name
FROM information_schema.columns
WHERE columns.table_schema::name = 'public'::name
  AND columns.table_name::name = 'adressen'::name
  AND (columns.column_name::name = ANY
       (ARRAY ['postcode'::name, 'huisnummer'::name, 'ingangsdatum'::name, 'einddatum'::name, 'telefoon'::name, 'med_mnr'::name]));

alter table s1_4_test
    owner to postgres;

