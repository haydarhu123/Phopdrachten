create view s5_7(voorl, naam) as
SELECT medewerkers.voorl,
       medewerkers.naam
FROM medewerkers
WHERE (medewerkers.chef IN (SELECT inschrijvingen.cursist
                            FROM inschrijvingen
                            WHERE inschrijvingen.cursist = medewerkers.chef
                              AND medewerkers.functie::text = 'TRAINER'::text));

alter table s5_7
    owner to postgres;

