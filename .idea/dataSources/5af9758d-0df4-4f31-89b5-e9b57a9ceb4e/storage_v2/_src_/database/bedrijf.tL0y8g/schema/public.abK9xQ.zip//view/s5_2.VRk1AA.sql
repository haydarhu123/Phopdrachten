create view s5_2(mnr) as
SELECT m.mnr
FROM medewerkers m
         JOIN afdelingen a ON a.anr = m.afd
WHERE a.anr <> 20::numeric;

alter table s5_2
    owner to postgres;

