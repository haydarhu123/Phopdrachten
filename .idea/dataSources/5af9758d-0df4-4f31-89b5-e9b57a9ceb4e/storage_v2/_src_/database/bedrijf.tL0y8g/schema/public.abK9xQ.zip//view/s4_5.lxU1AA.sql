create view s4_5(cursus, aantal) as
SELECT uitvoeringen.cursus,
       count(*) AS aantal
FROM uitvoeringen
GROUP BY uitvoeringen.cursus;

alter table s4_5
    owner to postgres;

