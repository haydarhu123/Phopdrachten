create view s5_8(naam) as
SELECT m.naam
FROM medewerkers m
WHERE NOT (m.mnr IN (SELECT u.docent
                     FROM uitvoeringen u
                     WHERE u.docent = m.mnr));

alter table s5_8
    owner to postgres;

