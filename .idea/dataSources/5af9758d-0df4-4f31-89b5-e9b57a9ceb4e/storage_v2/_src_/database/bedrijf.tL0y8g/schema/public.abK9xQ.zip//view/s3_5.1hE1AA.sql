create view s3_5(naam) as
SELECT m.naam
FROM medewerkers m
         JOIN inschrijvingen i ON i.cursist = m.mnr
WHERE i.cursus::text = 'S02'::text
  AND i.begindatum = '2019-04-12'::date;

alter table s3_5
    owner to postgres;

