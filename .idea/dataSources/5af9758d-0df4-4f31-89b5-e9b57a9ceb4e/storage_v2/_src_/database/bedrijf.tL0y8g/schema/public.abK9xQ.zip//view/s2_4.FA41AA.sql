create view s2_4(naam, voorl) as
SELECT medewerkers.naam,
       medewerkers.voorl
FROM medewerkers
WHERE medewerkers.naam::text <> 'JANSEN'::text
   OR medewerkers.voorl::text <> 'R'::text;

alter table s2_4
    owner to postgres;

