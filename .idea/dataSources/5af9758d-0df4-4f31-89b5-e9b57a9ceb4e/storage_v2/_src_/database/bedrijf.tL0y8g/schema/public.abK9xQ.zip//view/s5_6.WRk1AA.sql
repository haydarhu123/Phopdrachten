create view s5_6(cursus, begindatum, aantal_inschrijvingen) as
SELECT u.cursus,
       u.begindatum,
       (SELECT count(*) AS count
        FROM inschrijvingen i
        WHERE i.cursus::text = u.cursus::text
          AND i.begindatum = u.begindatum) AS aantal_inschrijvingen
FROM uitvoeringen u;

alter table s5_6
    owner to postgres;

