create view s1_1_test(column_name) as
SELECT columns.column_name
FROM information_schema.columns
WHERE columns.table_schema::name = 'public'::name
  AND columns.table_name::name = 'medewerkers'::name
  AND columns.column_name::name = 'geslacht'::name;

alter table s1_1_test
    owner to postgres;

