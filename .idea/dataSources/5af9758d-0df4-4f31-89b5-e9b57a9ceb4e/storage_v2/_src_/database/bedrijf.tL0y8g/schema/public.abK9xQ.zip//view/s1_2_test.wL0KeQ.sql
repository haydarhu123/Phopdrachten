create view s1_2_test(naam) as
SELECT m.naam
FROM medewerkers m
         JOIN afdelingen a ON m.mnr = a.hoofd
WHERE a.naam::text = 'ONDERZOEK'::text
  AND m.chef = 7839::numeric;

alter table s1_2_test
    owner to postgres;

