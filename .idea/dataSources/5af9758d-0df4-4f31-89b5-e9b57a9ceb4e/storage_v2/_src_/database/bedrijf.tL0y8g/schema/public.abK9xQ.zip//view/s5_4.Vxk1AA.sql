create view s5_4(naam) as
SELECT m.naam
FROM medewerkers m
WHERE (m.mnr IN (SELECT mdw.chef
                 FROM medewerkers mdw
                 WHERE m.mnr = mdw.chef));

alter table s5_4
    owner to postgres;

