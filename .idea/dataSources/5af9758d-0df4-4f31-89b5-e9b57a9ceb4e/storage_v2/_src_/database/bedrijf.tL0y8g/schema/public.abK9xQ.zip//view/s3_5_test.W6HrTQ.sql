create view s3_5_test(naam) as
SELECT medewerkers.naam
FROM medewerkers
WHERE medewerkers.mnr = ANY (ARRAY [7499::numeric, 7934::numeric, 7698::numeric, 7876::numeric]);

alter table s3_5_test
    owner to postgres;

