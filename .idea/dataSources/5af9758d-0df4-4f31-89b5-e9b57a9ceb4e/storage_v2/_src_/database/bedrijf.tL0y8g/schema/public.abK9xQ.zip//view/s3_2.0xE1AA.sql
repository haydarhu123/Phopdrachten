create view s3_2(cursist, docent) as
SELECT m.naam      AS cursist,
       docent.naam AS docent
FROM inschrijvingen i
         JOIN medewerkers m ON i.cursist = m.mnr
         JOIN uitvoeringen ON i.cursus::text = uitvoeringen.cursus::text AND uitvoeringen.begindatum = i.begindatum
         JOIN medewerkers docent ON uitvoeringen.docent = docent.mnr
WHERE i.cursus::text = 'S02'::text;

alter table s3_2
    owner to postgres;

