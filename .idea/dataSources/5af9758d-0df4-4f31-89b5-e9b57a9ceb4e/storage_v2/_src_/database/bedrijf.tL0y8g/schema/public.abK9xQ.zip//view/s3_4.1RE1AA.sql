create view s3_4(naam, afdeling, locatie) as
SELECT m.naam,
       a.naam AS afdeling,
       a.locatie
FROM medewerkers m
         JOIN afdelingen a ON a.anr = m.afd;

alter table s3_4
    owner to postgres;

