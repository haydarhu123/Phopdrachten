create view s4_3(code, begindatum, aantal_inschrijvingen) as
SELECT inschrijvingen.cursus AS code,
       inschrijvingen.begindatum,
       count(*)              AS aantal_inschrijvingen
FROM inschrijvingen
GROUP BY inschrijvingen.cursus, inschrijvingen.begindatum
HAVING count(*) >= 3
   AND inschrijvingen.begindatum >= '2019-01-01'::date
   AND inschrijvingen.begindatum <= '2020-01-01'::date;

alter table s4_3
    owner to postgres;

