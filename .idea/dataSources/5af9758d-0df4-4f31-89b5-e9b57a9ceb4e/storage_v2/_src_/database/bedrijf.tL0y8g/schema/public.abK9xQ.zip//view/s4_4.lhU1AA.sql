create view s4_4(mnr, cursus) as
SELECT m.mnr,
       i.cursus
FROM medewerkers m
         JOIN inschrijvingen i ON i.cursist = m.mnr
GROUP BY i.cursus, m.mnr
HAVING count(*) > 1;

alter table s4_4
    owner to postgres;

