create view s2_2 (mnr, naam, voorl, functie, chef, gbdatum, maandsal, comm, afd, geslacht) as
SELECT medewerkers.mnr,
       medewerkers.naam,
       medewerkers.voorl,
       medewerkers.functie,
       medewerkers.chef,
       medewerkers.gbdatum,
       medewerkers.maandsal,
       medewerkers.comm,
       medewerkers.afd,
       medewerkers.geslacht
FROM medewerkers
ORDER BY medewerkers.gbdatum;

alter table s2_2
    owner to postgres;

