create view s4_5_test(cursus, aantal) as
SELECT answer.cursus,
       answer.aantal
FROM (VALUES ('JAV'::character varying(4), 2::bigint),
             ('S02'::character varying, 3),
             ('PRO'::character varying, 1),
             ('OAG'::character varying, 2),
             ('RSO'::character varying, 1),
             ('ERM'::character varying, 1),
             ('PLS'::character varying, 1),
             ('XML'::character varying, 2)) answer(cursus, aantal);

alter table s4_5_test
    owner to postgres;

