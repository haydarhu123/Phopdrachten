create view s3_1(cursus, begindatum, lengte, naam) as
SELECT uitvoeringen.cursus,
       uitvoeringen.begindatum,
       c.lengte,
       m.naam
FROM uitvoeringen
         JOIN medewerkers m ON uitvoeringen.docent = m.mnr
         JOIN cursussen c ON c.code::text = uitvoeringen.cursus::text;

alter table s3_1
    owner to postgres;

