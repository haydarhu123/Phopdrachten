create view s3_6(naam, toelage) as
SELECT m.naam,
       s.toelage
FROM medewerkers m
         JOIN schalen s ON m.maandsal >= s.ondergrens AND m.maandsal <= s.bovengrens;

alter table s3_6
    owner to postgres;

