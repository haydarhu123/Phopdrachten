create view s4_1(nummer, functie, geboortedatum) as
SELECT medewerkers.mnr     AS nummer,
       medewerkers.functie,
       medewerkers.gbdatum AS geboortedatum
FROM medewerkers
WHERE (medewerkers.functie::text = 'TRAINER'::text OR medewerkers.functie::text = 'VERKOPER'::text)
  AND medewerkers.gbdatum < '1980-01-01'::date;

alter table s4_1
    owner to postgres;

