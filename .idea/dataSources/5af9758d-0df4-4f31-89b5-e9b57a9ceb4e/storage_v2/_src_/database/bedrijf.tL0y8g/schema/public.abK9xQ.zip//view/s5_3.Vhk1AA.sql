create view s5_3(mnr) as
SELECT m.mnr
FROM medewerkers m
WHERE NOT (m.mnr IN (SELECT i.cursist
                     FROM inschrijvingen i
                     WHERE i.cursus::text ~~ 'JAV'::text));

alter table s5_3
    owner to postgres;

