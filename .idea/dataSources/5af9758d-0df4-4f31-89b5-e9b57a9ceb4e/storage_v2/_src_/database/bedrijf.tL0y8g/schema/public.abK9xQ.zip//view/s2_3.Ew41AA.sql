create view s2_3(cursus, begindatum) as
SELECT uitvoeringen.cursus,
       uitvoeringen.begindatum
FROM uitvoeringen
WHERE uitvoeringen.locatie::text = 'UTRECHT'::text
   OR uitvoeringen.locatie::text = 'MAASTRICHT'::text;

alter table s2_3
    owner to postgres;

